package protopito;

public class MejoraClicker extends Mejora {

	private double incrClicker;

	public MejoraClicker() {
	}

	public MejoraClicker(String nombre, double coste, double incrClicker, double incrCoste,
			double requisitoDesbloqueo) {
		super(nombre, coste, incrClicker, incrCoste, requisitoDesbloqueo);
		this.incrClicker = incrClicker;
	}

	public boolean comprarClick(Datos datos, double incrClicker, double incrCoste) {

		if (!datos.verificarCompra(coste))
			return false;

		datos.gastar(coste);
		nivel++;
		datos.subirClicker(incrClicker);
		// sube los clicks
		coste *= incrCoste;
		// sube coste
		return true;
	}

	@Override
	public boolean desbloquado(double numActual) {
		return numActual >= requisitoDesbloqueo;
	}

	public double getIncrClicker() {
		return incrClicker;
	}

	public void setIncrClicker(double incrClicker) {
		this.incrClicker = incrClicker;
	}

}
