
package protopito;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.RenderingHints;

import javax.swing.ButtonModel;
import javax.swing.JButton;

@SuppressWarnings("serial")
public class BotonClicker extends JButton {
	private int radius = 80;

	// colores
	private Color normalBg = new Color(210, 255, 210);
	private Color hoverBg = new Color(180, 245, 180);
	private Color pressedBg = new Color(140, 230, 140);
	private Color disabledBg = new Color(210, 210, 210);

	private Color borderColor = new Color(90, 140, 90);

	public BotonClicker() {
		super();

		setRolloverEnabled(true);

		// quita el pintado del Look&Feel
		setContentAreaFilled(false);
		setBorderPainted(false);
		setFocusPainted(false);
		setOpaque(false);

		// padding interno
		setMargin(new Insets(20, 40, 20, 40));

		// Fuente por defecto
		setFont(getFont().deriveFont(Font.BOLD, 22f));

		setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	}

	@Override
	protected void paintComponent(Graphics g) {
		Graphics2D g2 = (Graphics2D) g.create();
		try {
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

			ButtonModel model = getModel();

			// Elegimos color según estado
			Color bg;

			if (!isEnabled()) {
				bg = disabledBg;
			} else if (model.isPressed()) {
				bg = pressedBg;
			} else if (model.isRollover()) {
				bg = hoverBg;
			} else {
				bg = normalBg;
			}

			// Fondo redondeado
			int w = getWidth();
			int h = getHeight();

			g2.setColor(bg);
			g2.fillRoundRect(0, 0, w - 1, h - 1, radius, radius);

			// Borde
			g2.setColor(borderColor);
			g2.drawRoundRect(0, 0, w - 1, h - 1, radius, radius);

			// Pinta el texto e icono encima del fondo
			super.paintComponent(g2);
		} finally {
			g2.dispose();
		}
	}

	// Opcional: permite ajustar radio desde código
	public void setRadius(int radius) {
		this.radius = radius;
		repaint();
	}

	// Opcional: permite ajustar colores desde código
	public void setColors(Color normal, Color hover, Color pressed) {
		this.normalBg = normal;
		this.hoverBg = hover;
		this.pressedBg = pressed;
		repaint();
	}
}