package protopito;

public class Mejora {

	protected String nombre;
	protected int nivel;
	protected double coste;
	protected double incrNPS;
	protected double incrCoste;
	protected double requisitoDesbloqueo;

	public Mejora() {
	}

	public Mejora(String nombre, double coste, double incrNPS, double incrCoste, double requisitoDesbloqueo) {
		this.nombre = nombre;
		this.nivel = 1;
		this.coste = coste;
		this.incrNPS = incrNPS;
		this.incrCoste = incrCoste;
		this.requisitoDesbloqueo = requisitoDesbloqueo;
	}

	public boolean desbloquado(double numActual) {
		return numActual >= requisitoDesbloqueo;
	}

	public boolean comprar(Datos datos, double incrNPS, double incrCoste) {

		if (!datos.verificarCompra(coste))
			return false;

		datos.gastar(coste);
		nivel++;
		datos.subirNPS(incrNPS);
		// sube los nps
		coste *= incrCoste;
		// sube coste
		return true;
	}

	public double getIncrNPS() {
		return incrNPS;
	}

	public void setIncrNPS(double incrNPS) {
		this.incrNPS = incrNPS;
	}

	public double getIncrCoste() {
		return incrCoste;
	}

	public void setIncrCoste(double incrCoste) {
		this.incrCoste = incrCoste;
	}

	public String getNombre() {
		return nombre;
	}

	public int getNivel() {
		return nivel;
	}

	public double getCoste() {
		return coste;
	}

	public void setCoste(double coste) {
		this.coste = coste;
	}

}
