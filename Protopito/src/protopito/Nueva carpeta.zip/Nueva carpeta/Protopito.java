package protopito;

import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class Protopito {
// TODO 
	// * revertir texto coste y boton
	// * añadir clicker
	// añadir boton se clicke solo cada x tiempo con mejora
	// elemento gatcha
	// objetos consumibles

	private Datos datos = new Datos();
	public static List<Mejora> mejoras = new ArrayList<>();
	public static List<MejoraClicker> mejorasClicker = new ArrayList<>();

	public Protopito() {
		// activas nombre / coste / incrementoClicker / incrementoCoste /
		// umbralDesbloqueo
		mejorasClicker.add(new MejoraClicker("Clicker", 10, 0.55, 1.5, 10));
		// pasivas nombre / coste / incrementoNps / incrementoCoste/ umbralDesbloqueo
		mejoras.add(new Mejora("Infra Pito", 10, 0.15, 1.25, 10));
		mejoras.add(new Mejora("Micro Pito", 50, 0.45, 1.25, 50));
		mejoras.add(new Mejora("Pitilin", 100, 0.95, 1.25, 100));
		mejoras.add(new Mejora("Pito", 500, 2.15, 1.25, 500));
		mejoras.add(new Mejora("Super Pito", 5000, 4.8, 1.31, 5000));
		mejoras.add(new Mejora("Mega Pito", 50000, 15.50, 1.38, 50000));
		mejoras.add(new Mejora("Hyper Pito", 150000, 200.5, 1.42, 150000));
		mejoras.add(new Mejora("Ultra Pito", 500000, 4030.50, 1.77, 500000));
	}

	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> new Protopito().raiz());
	}

	private void raiz() {
		Interfaz interfaz = new Interfaz(datos, mejoras, mejorasClicker);
		interfaz.render();
		timer(interfaz);
	}

	// loop que se actualiza cada 0.025 segundos
	private void timer(Interfaz interfaz) {

		new Timer(25, ejecuta -> {
			datos.reloj(0.025);
			interfaz.render();
		}).start();
	}

}
